This project is a web application to show Maadi map in Egypt with some favorite places.
To run this project: Open 'index.html' with your favorite browser.